Steps to run the server
1) Open terminal and change directory to the unzipped folder
2) Run command "pip install -r requirements.txt
3) Run command "python app.py"
4) open "http://localhost:5000/" in browser to view the graph/data


